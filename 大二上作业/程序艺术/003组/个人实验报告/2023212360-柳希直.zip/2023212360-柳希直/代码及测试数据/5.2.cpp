#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

const int INF = 9999999;

int main() {
    int L;
    cin >> L;
    int S, T, M;
    cin >> S, cin >> T, cin >> M;
    vector<int> stones(M);
    for (int i = 0; i < M; ++i) {
        cin >> stones[i];
    }
    sort(stones.begin(), stones.end());

    vector<int> dp(L + 1, INF);
    dp[0] = 0;

    vector<bool> stonePos(L + 1, false);
    for (int stone : stones) {
        stonePos[stone] = true;
    }

    for (int i = 1; i <= L; ++i) {
        for (int j = S; j <= T; ++j) {
            if (i - j >= 0) {
                dp[i] = min(dp[i], dp[i - j] + stonePos[i]);
            }
            else {
                break;
            }
        }
    }

    cout << dp[L] << endl;

    return 0;
}