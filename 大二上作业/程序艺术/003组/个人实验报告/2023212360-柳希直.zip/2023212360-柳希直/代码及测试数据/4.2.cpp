#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

int main() {
	int n, k;
	cin >> n >> k;
	vector<int> h;
	int s;
	for (int i = 0; i < n; i++) {
		cin >> s;
		h.push_back(s);
	}
	int min = 9999999;
	for (int i = 0; i < n-k+1; i++) {
		vector<int>::iterator a = h.begin() + i;
		int max=0, max2=0;
		for (vector<int>::iterator j = a; j < a + k; j++) {
			if (*j<=max && *j>max2) {
				max2 = *j;
			}
			if (*j > max) {
				max2 = max;
				max = *j;
			}
		}
		if ((max - max2) < min) {
			min = max - max2;
		}
	}
	cout << min << endl;

}