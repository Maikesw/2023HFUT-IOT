#include<iostream>
#include<vector>

using namespace std;

bool t(vector<int>s,int n) {
	int count = 0;
	for (int i = 1; i < s.size()+1; i++) {
		auto it = s.begin() + i - 1;
		if (*it == i) { count++; }
	}
	if (count == n)return true;
	return false;

}

int test(vector<int>::iterator it, vector<int>::iterator end,int key) {
	if (it == end)return 0;
	if (*it == key) {
		
		int a = (test(it + 1, end, key));
		int b = (test(it + 1, end, key + 1) + 1);
		return max(a, b);
	}
	else {
		int a = (test(it + 1, end, key));
		int b = (test(it + 1, end, key + 1));
		return max(a, b);
	}
}

int main() {
	int n,I;
	cin >> n;
	vector<int> D;
	for (int i = 0; i < n; i++) {
		cin >> I;
		D.push_back(I);
	}
	vector<int>s;
	vector<int>::iterator it=D.begin();
	int key = 1;
	int r = test(it, D.end(), key);
	cout << r;
	
	

}
