#include<iostream>

using namespace std;

int main() {
	string A, B;
	string C = "";
	cin >> A >> B;
	if (A.length() > B.length()) {
		cout << -1;
		return -1;
	}

	bool f = 1;
	for (int i = 0; i < B.length(); i++) {
		int c1 = 0, c2 = 0;
		for (int j = 0; j < A.length(); j++) {
			if (A[j] > A[c1]) {
				c1 = j;
			}
			if (A[j] > A[c2] && A[j] <= B[i]) {
				c2 = j;
			}
		}
		if (f && A[c2] < B[i]) {
			C += A[c2];
			A.erase(c2, 1);
			f = 0;
		}
		else if (f && A[c2] == B[i]) {
			C += A[c2];
			A.erase(c2, 1);
		}
		else if (f && C.length()) {
			for (int i = C.length() - 1; i >= 0; i--) {
				for (int j = i - 1; j >= 0; j--) {
					if (C[j] > C[i]) {
						f = 0;
						swap(C[j], C[i]);
						C += A[c1];
						A.erase(c1, 1);
						break;
					}
				}
				if (!f)break;
			
			}
		}
		else if (!f) {
			C += A[c1];
			A.erase(c1, 1);
		}
		else {
			cout << -1 << endl;
			return -1;
		}
	}
	cout << C;
	return 0;
}
