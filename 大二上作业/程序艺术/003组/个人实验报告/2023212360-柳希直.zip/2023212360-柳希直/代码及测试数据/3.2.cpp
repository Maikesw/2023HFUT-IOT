#include<iostream>
#include<vector>
#include<map>

using namespace std;

int main() {
	int n,s;
	cin >> n;
	vector<int> r;
	for (int i = 0; i < n; i++) {
		cin >> s;
		r.push_back(s);
	}
	
	map<int, int> dict;
	for (vector<int>::iterator it = r.begin(); it < r.end(); it++) {
		dict[*it] += 1;
		
		cout << dict[*it] << " ";
	}
	cout << endl;

}