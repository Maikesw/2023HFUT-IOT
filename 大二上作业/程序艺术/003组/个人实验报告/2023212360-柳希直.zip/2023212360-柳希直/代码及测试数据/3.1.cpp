#include<iostream>
#include<vector>
using namespace std;

int main() {
	int n,i;
	cin >> n;
	int c;
	int s;
	vector<int> r;
	for (int j = 0; j < n; j++) {
		cin >>c;
		vector<int> d;
		for (int k = 0; k < c; k++) {
			cin >> s;
			d.push_back(s);
		}
		if (c == 1) {
			r.push_back(d[0]);
		}
		if (c == 2) {
			i = d[0];
			int sum = r[i];
			int count = 0;
			if (sum == d[1]) { count++; }
			for (int k = i - 1; k >= 0; k--) {
				sum += r[k];
				if (sum == d[1]) { count++; }
			}
			sum = r[i];
			for (int k = i + 1; k < r.size(); k++) {
				sum += r[k];
				if (sum == d[1]) { count++; }
			}
			cout << count << endl;
		}
	}
}