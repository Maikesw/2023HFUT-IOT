#include<iostream>
#include<vector>
#include<map>
#include<iomanip>
using namespace std;

double Max_return(vector<int>L, vector<double>p, int n, int t) {
    vector<double>r(n);
    vector<int>b(n, 0);
    for (int i = 0; i < n; i++) {
        r[i] = p[i] / (L[i] + 1);
    }
    vector<double>::iterator r_i;
    for (int i = 0; i < t; i++) {
        r_i = max_element(r.begin(), r.end());
        b[r_i - r.begin()] += 1;
        if (b[r_i - r.begin()] == L[r_i - r.begin()]) {
            *r_i = 0;
        }
        else {
            *r_i = p[r_i - r.begin()] * b[r_i - r.begin()] / (b[r_i - r.begin()] + L[r_i - r.begin()]);
        }
    }
    double Ret = 0.0;
    for (int i = 0; i < n; i++) {
        Ret += p[i] * b[i] / (b[i] + L[i]);
    }
    return Ret;
}

int main() {
    int n, t, q;
    cin >> n >> t >> q;
    vector<double> p(n);
    for (int i = 0; i < n; i++) {
        cin >> p[i];
    }
    vector<int> L(n);
    for (int i = 0; i < n; i++) {
        cin >> L[i];
    }
    vector<pair<int, int>> C(q);
    for (int i = 0; i < q; i++) {
        cin >> C[i].first >> C[i].second;
    }
    int k = 0;
    while (k < q) {
        if (C[k].first == 1) {
            L[C[k].second - 1] += 1;
        }
        if (C[k].first == 2) {
            L[C[k].second - 1] -= 1;
        }
        cout << fixed << setprecision(9) << Max_return(L, p, n, t) << endl;
        k++;
    }
}