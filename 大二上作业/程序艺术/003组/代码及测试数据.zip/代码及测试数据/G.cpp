#include<bits/stdc++.h>
#define pi 3.1415926
using namespace std;
double r;
struct Node {
	double x,y,z;
} a,b,c;
double di(const Node &a,const Node &b) {
	double x=a.x-b.x,y=a.y-b.y,z=a.z-b.z;
	return sqrt(x*x+y*y+z*z);
}
int main() {
	scanf("%lf%lf%lf",&a.x,&a.y,&a.z);
	scanf("%lf%lf%lf",&b.x,&b.y,&b.z);
	scanf("%lf%lf%lf",&c.x,&c.y,&c.z);
	scanf("%lf",&r);
	double s1=b.x-a.x,s2=b.y-a.y,s3=b.z-a.z;
	double l=sqrt(s1*s1+s2*s2+s3*s3);
	s1/=l; s2/=l; s3/=l;
	//ABֱ�߷�������s 
	double v1=c.x-a.x,v2=c.y-a.y,v3=c.z-a.z;
	//A-C����v 
	double sv=s1*v1+s2*v2+s3*v3;
	double d=sqrt(fabs(v1*v1+v2*v2+v3*v3-sv*sv));
	//d=sqrt(|v|^2-((sv)/|s|)^2)
	if(r-d<1e-7) {
		printf("%.2lf\n",di(a,b));
		exit(0);
	}
	double da=di(a,c),db=di(b,c),dab=di(a,b);
	double th=acos((da*da+db*db-dab*dab)/(2*da*db));
	th-=acos(r/da)+acos(r/db);
	double ans=sqrt(da*da-r*r)+sqrt(db*db-r*r)+r*th;
	printf("%.2lf\n",ans);
	return 0;
}
