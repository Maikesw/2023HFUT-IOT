// Editbox.cpp : implementation file
//

#include "stdafx.h"
#include "luoji.h"
#include "Editbox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditbox

CEditbox::CEditbox()
{
}

CEditbox::~CEditbox()
{
}


BEGIN_MESSAGE_MAP(CEditbox, CEdit)
	//{{AFX_MSG_MAP(CEditbox)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditbox message handlers
