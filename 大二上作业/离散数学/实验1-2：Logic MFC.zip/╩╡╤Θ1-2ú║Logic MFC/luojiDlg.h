// luojiDlg.h : header file
//

#if !defined(AFX_LUOJIDLG_H__3F232397_1516_4C56_8F50_00DDC7F9957D__INCLUDED_)
#define AFX_LUOJIDLG_H__3F232397_1516_4C56_8F50_00DDC7F9957D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CLuojiDlg dialog

class CLuojiDlg : public CDialog
{
// Construction
public:
	CLuojiDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CLuojiDlg)
	enum { IDD = IDD_LUOJI_DIALOG };
	CComboBox	m_Select;
	CEdit	m_Result;
	CEdit	m_Valuetwo;
	CEdit	m_Valueone;
	CButton	m_Button;
	CEdit	m_Edit4;
	CEdit	m_Edit3;
	CEdit	m_Edit1;
	CEdit	m_Info;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLuojiDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CLuojiDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSelchangeCombo2();
	afx_msg void OnButton1();
	afx_msg void OnCalculate();
	afx_msg void OnInstruction();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LUOJIDLG_H__3F232397_1516_4C56_8F50_00DDC7F9957D__INCLUDED_)
