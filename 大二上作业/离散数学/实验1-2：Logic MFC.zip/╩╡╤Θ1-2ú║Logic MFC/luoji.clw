; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CLuojiDlg
LastTemplate=CEdit
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "luoji.h"

ClassCount=4
Class1=CLuojiApp
Class2=CLuojiDlg
Class3=CAboutDlg

ResourceCount=3
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Class4=CEditbox
Resource3=IDD_LUOJI_DIALOG

[CLS:CLuojiApp]
Type=0
HeaderFile=luoji.h
ImplementationFile=luoji.cpp
Filter=N

[CLS:CLuojiDlg]
Type=0
HeaderFile=luojiDlg.h
ImplementationFile=luojiDlg.cpp
Filter=D
LastObject=IDC_EDIT2
BaseClass=CDialog
VirtualFilter=dWC

[CLS:CAboutDlg]
Type=0
HeaderFile=luojiDlg.h
ImplementationFile=luojiDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_LUOJI_DIALOG]
Type=1
Class=CLuojiDlg
ControlCount=11
Control1=IDC_STATIC,static,1342308352
Control2=IDC_COMBO2,combobox,1344340227
Control3=IDC_STATIC,static,1342308352
Control4=IDC_EDIT2,edit,1350631552
Control5=IDC_STATIC,static,1342308352
Control6=IDC_STATIC,static,1342308352
Control7=VAL_ONE,edit,1350631552
Control8=VAL_TWO,edit,1350631552
Control9=IDC_CALCULATE,button,1342242816
Control10=IDC_STATIC,static,1342308352
Control11=IDC_RESULT,edit,1350631552

[CLS:CEditbox]
Type=0
HeaderFile=Editbox.h
ImplementationFile=Editbox.cpp
BaseClass=CEdit
Filter=W

