#if !defined(AFX_EDITBOX_H__E7543B08_DEDF_4733_A3F5_755A9F791B19__INCLUDED_)
#define AFX_EDITBOX_H__E7543B08_DEDF_4733_A3F5_755A9F791B19__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Editbox.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEditbox window

class CEditbox : public CEdit
{
// Construction
public:
	CEditbox();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditbox)
	//}}AFX_VIRTUAL

// Implementation
public:
	CEdit m_Info1;
	virtual ~CEditbox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CEditbox)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITBOX_H__E7543B08_DEDF_4733_A3F5_755A9F791B19__INCLUDED_)
