// luoji.h : main header file for the LUOJI application
//

#if !defined(AFX_LUOJI_H__28A147EC_6A02_487A_953C_3A033A2B98B7__INCLUDED_)
#define AFX_LUOJI_H__28A147EC_6A02_487A_953C_3A033A2B98B7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CLuojiApp:
// See luoji.cpp for the implementation of this class
//

class CLuojiApp : public CWinApp
{
public:
	CLuojiApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLuojiApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CLuojiApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LUOJI_H__28A147EC_6A02_487A_953C_3A033A2B98B7__INCLUDED_)
