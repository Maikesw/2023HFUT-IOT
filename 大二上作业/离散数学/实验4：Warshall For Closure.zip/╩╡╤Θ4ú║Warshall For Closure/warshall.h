// warshall.h : main header file for the WARSHALL application
//

#if !defined(AFX_WARSHALL_H__C343DE39_77C6_45CA_B663_AFEBC5315B99__INCLUDED_)
#define AFX_WARSHALL_H__C343DE39_77C6_45CA_B663_AFEBC5315B99__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CWarshallApp:
// See warshall.cpp for the implementation of this class
//

class CWarshallApp : public CWinApp
{
public:
	CWarshallApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWarshallApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CWarshallApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WARSHALL_H__C343DE39_77C6_45CA_B663_AFEBC5315B99__INCLUDED_)
