; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CWarshallDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "warshall.h"

ClassCount=3
Class1=CWarshallApp
Class2=CWarshallDlg
Class3=CAboutDlg

ResourceCount=3
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource3=IDD_WARSHALL_DIALOG

[CLS:CWarshallApp]
Type=0
HeaderFile=warshall.h
ImplementationFile=warshall.cpp
Filter=N

[CLS:CWarshallDlg]
Type=0
HeaderFile=warshallDlg.h
ImplementationFile=warshallDlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=CWarshallDlg

[CLS:CAboutDlg]
Type=0
HeaderFile=warshallDlg.h
ImplementationFile=warshallDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_WARSHALL_DIALOG]
Type=1
Class=CWarshallDlg
ControlCount=10
Control1=IDC_STATIC,static,1342308352
Control2=DIMENSION,edit,1350631552
Control3=IDC_STATIC,static,1342308352
Control4=STRING,edit,1350631552
Control5=IDC_STATIC,static,1342308352
Control6=MATRIX,edit,1350635588
Control7=IDC_STATIC,static,1342308352
Control8=RESULT,edit,1342246980
Control9=IDC_MATRIX,button,1342242816
Control10=IDC_CALCULATE,button,1342242816

