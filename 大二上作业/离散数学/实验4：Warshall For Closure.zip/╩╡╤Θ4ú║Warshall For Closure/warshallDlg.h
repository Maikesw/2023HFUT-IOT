/**********************************************************
 Discrete Mathematics experiments platform
 Programed by Wang Xiaohua
 School of Computer Science and Information
 HeFei University of Technology
**********************************************************/

// warshallDlg.h : header file
//

#if !defined(AFX_WARSHALLDLG_H__3EE28198_74E9_4392_B393_51CBE079BD37__INCLUDED_)
#define AFX_WARSHALLDLG_H__3EE28198_74E9_4392_B393_51CBE079BD37__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CWarshallDlg dialog

class CWarshallDlg : public CDialog
{
// Construction
public:
	CWarshallDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CWarshallDlg)
	enum { IDD = IDD_WARSHALL_DIALOG };
	CEdit	m_Edit2;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWarshallDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CWarshallDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
//	afx_msg void OnButton1();
//	afx_msg void OnButton2();
	afx_msg void OnMatrix();
	afx_msg void OnCalculate();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WARSHALLDLG_H__3EE28198_74E9_4392_B393_51CBE079BD37__INCLUDED_)
