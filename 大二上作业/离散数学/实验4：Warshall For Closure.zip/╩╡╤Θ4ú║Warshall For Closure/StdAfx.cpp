/**********************************************************
 Discrete Mathematics experiments platform
 Programed by Wang Xiaohua
 School of Computer Science and Information
 HeFei University of Technology
**********************************************************/

// stdafx.cpp : source file that includes just the standard includes
//	warshall.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"



