//Stack.cpp
#include "Stack.h"  
intStack::~intStack()  
{  
    intNode *p;  
    while (NULL != top)  
    {  
        p = top;  
        top = top->next;  
        delete p;  
    }  
}  
void intStack::push(int value)              //�߼�ֵ��ջ
{  
    top = new intNode(value,top);  
}  
int intStack::pop()                         //�߼�ֵ��ջ
{  
    if (!isEmpty())  
    {  
        intNode *p;  
        p = top;  
        top = top->next;  
        int nodeValue = p->value;  
        delete p;  
        return nodeValue;  
    }  
}  
void intStack::makeEmpty()                  //��ʼ���߼�ֵջ
{  
    intNode *p;  
    while (NULL != top)  
    {  
        p = top;  
        top = top->next;  
        delete p;  
    }  
}  
int intStack::getTop()                      //�õ�ջ��Ԫ��

{  
    return top->value;  
}  
CharStack::~CharStack()  
{  
    CharNode *p;  
    while (NULL != top)  
    {  
        p = top;  
        top = top->next;  
        delete p;  
    }  
}  
void CharStack::push(char value)             //�������ջ
{  
    top = new CharNode(value,top);  
}  
char CharStack::pop()                        //�������ջ
{  
    if (!isEmpty())  
    {  
        CharNode *p;  
        p = top;  
        top = top->next;  
        char nodeValue = p->value;  
        delete p;  
        return nodeValue;  
    }  
}  
void CharStack::makeEmpty()                  //��ʼ�������ջ
{  
    CharNode *p;  
    while (NULL != top)  
    {  
        p = top;  
        top = top->next;  
        delete p;  
    }  
}  
char CharStack::getTop()                     //�õ�ջ��Ԫ��
{  
    return top->value;  
}



int CharStack::stacklength()                 //�õ�ջ�ĳ���
{
	CharNode *p;
	int n=0;
	p=top;
	while (p!=NULL)
	{
		n++;
		p=p->next;
	}
	return (n);	 
}