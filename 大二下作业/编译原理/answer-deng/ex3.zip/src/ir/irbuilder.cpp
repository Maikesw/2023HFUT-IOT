#include "ir/irbuilder.hpp"

void ir::IrBuilder::visit(ast::compunit_syntax &node)
{
    /*
        init global variable
    */

    this->compunit = std::make_shared<ir::ir_module>();
    /*
        register lib functions
    */

    /*
        visit children
    */
    for(auto & i : node.global_defs)
        i->accept(*this);
}

void ir::IrBuilder::visit(ast::func_def_syntax &node){
    auto rettype = node.rettype;
    string name = node.name;
    
    this->cur_block = nullptr;
    this->cur_func = nullptr;
    this->cur_func_name = "";
    this->found_main = false;
    this->return_bb = nullptr;
    this->return_value.clear();
    /*
        first we should register this function in symbol table
    */
    cur_func = compunit->new_func(name);
    this->functions.push_func(name,cur_func);
    /*
        next we should deal with entry module
        in this module, we should insert instructions which is responsible for args.  
    */
    cur_func->entry = cur_func->new_block();
    cur_block = cur_func->entry;
    if(name == "main"){
        this->found_main = true;
    }
    return_bb = cur_func->new_block();
    /*
        deal with block
    */
    node.body->accept(*this);
    /*
        deal with ret
    */
    switch (rettype)
    {
    case vartype::VOID:
        {
            cur_block->push_back(std::make_shared<ir::jump>(return_bb));
            auto ret_value = std::make_shared<ir::ir_constant>(0);
            return_bb->push_back(std::make_shared<ir::ret>(ret_value,false));
            //false express non return
        }
        break;
    default:
        {
            auto ret_val = std::make_shared<ir::ir_constant>(0);
            return_value.emplace_back(ret_val,cur_block);
            cur_block->push_back(std::make_shared<ir::jump>(return_bb));
            /*
                set a default value to last block
            */
            /*
                add a phi inst
            */
            auto ret_dst = cur_func->new_reg(vartype::INT);
            auto phi_inst = std::make_shared<ir::phi>(ret_dst);
            phi_inst->uses = return_value;
            return_bb->push_back(phi_inst);
            return_bb->push_back(std::make_shared<ir::ret>(ret_dst,true));
        }
        break;
    }
}

void ir::IrBuilder::visit(ast::rel_cond_syntax &node)
{
    // 访问左操作数和右操作数
    node.lhs->accept(*this);
    auto lhs = pass_value;
    node.rhs->accept(*this);
    auto rhs = pass_value;
    
    // 创建目标寄存器存储比较结果
    auto dst = cur_func->new_reg(vartype::INT);
    
    // 创建比较指令
    cur_block->push_back(std::make_shared<ir::cmp_ins>(dst, lhs, rhs, node.op));
    
    // 设置返回值
    this->pass_value = dst;
}

void ir::IrBuilder::visit(ast::logic_cond_syntax &node)
{
    // 处理逻辑操作符（&& 和 ||）
    node.lhs->accept(*this);
    auto lhs = pass_value;
    node.rhs->accept(*this);
    auto rhs = pass_value;
    
    // 创建新的寄存器存储结果
    auto dst = cur_func->new_reg(vartype::INT);
    
    // 根据操作符生成指令
    if (node.op == relop::op_and) {
        // 实现 AND 操作（x && y）
        // 在 LLVM IR 中，可以使用简单的乘法来模拟 AND
        auto zero = std::make_shared<ir::ir_constant>(0);
        auto cmp1 = cur_func->new_reg(vartype::INT);
        auto cmp2 = cur_func->new_reg(vartype::INT);
        
        // 检查 lhs != 0
        cur_block->push_back(std::make_shared<ir::cmp_ins>(cmp1, lhs, zero, relop::non_equal));
        
        // 检查 rhs != 0
        cur_block->push_back(std::make_shared<ir::cmp_ins>(cmp2, rhs, zero, relop::non_equal));
        
        // 使用乘法模拟 AND
        cur_block->push_back(std::make_shared<ir::binary_op_ins>(dst, cmp1, cmp2, binop::multiply));
    } 
    else if (node.op == relop::op_or) {
        // 实现 OR 操作（x || y）
        auto zero = std::make_shared<ir::ir_constant>(0);
        auto cmp1 = cur_func->new_reg(vartype::INT);
        auto cmp2 = cur_func->new_reg(vartype::INT);
        auto temp = cur_func->new_reg(vartype::INT);
        
        // 检查 lhs != 0
        cur_block->push_back(std::make_shared<ir::cmp_ins>(cmp1, lhs, zero, relop::non_equal));
        
        // 检查 rhs != 0
        cur_block->push_back(std::make_shared<ir::cmp_ins>(cmp2, rhs, zero, relop::non_equal));
        
        // 使用加法和比较模拟 OR
        cur_block->push_back(std::make_shared<ir::binary_op_ins>(temp, cmp1, cmp2, binop::plus));
        cur_block->push_back(std::make_shared<ir::cmp_ins>(dst, temp, zero, relop::greater));
    }
    
    // 设置返回值
    this->pass_value = dst;
}

void ir::IrBuilder::visit(ast::binop_expr_syntax &node)
{
    /*
        the output of binary expression is a value, not a condition
    */
    node.lhs->accept(*this);
    auto exp1=pass_value;
    node.rhs->accept(*this);
    auto exp2=pass_value;
    auto dst = cur_func->new_reg(vartype::INT);
    cur_block->push_back(std::make_shared<ir::binary_op_ins>(dst,exp1,exp2,node.op));
    this->pass_value=dst;
}

void ir::IrBuilder::visit(ast::unaryop_expr_syntax &node)
{
    // 访问操作数
    node.rhs->accept(*this);
    auto operand = pass_value;
    
    // 根据操作符类型处理
    switch (node.op) {
        case unaryop::plus:
            // +x 等价于 x
            this->pass_value = operand;
            break;
        case unaryop::minus:
            // -x 等价于 0-x
            {
                auto zero = std::make_shared<ir::ir_constant>(0);
                auto dst = cur_func->new_reg(vartype::INT);
                cur_block->push_back(std::make_shared<ir::binary_op_ins>(dst, zero, operand, binop::minus));
                this->pass_value = dst;
            }
            break;
        case unaryop::op_not:
            // !x 等价于 x == 0
            {
                auto zero = std::make_shared<ir::ir_constant>(0);
                auto dst = cur_func->new_reg(vartype::INT);
                cur_block->push_back(std::make_shared<ir::cmp_ins>(dst, operand, zero, relop::equal));
                this->pass_value = dst;
            }
            break;
    }
}

void ir::IrBuilder::visit(ast::lval_syntax &node)
{
    // 获取变量名
    auto var_name = node.name;
    
    // 在符号表中查找变量
    auto var = scope.find_var(var_name);
    
    if (!var) {
        std::cerr << "Error: Variable " << var_name << " not found!" << std::endl;
        exit(1);
    }
    
    // 获取变量的值（加载到寄存器中）
    auto dst = cur_func->new_reg(vartype::INT);
    cur_block->push_back(std::make_shared<ir::load>(dst, var->get_addr()));
    this->pass_value = dst;
}

void ir::IrBuilder::visit(ast::literal_syntax &node)
{
    auto constant = std::make_shared<ir::ir_constant>(node.intConst);
    pass_value = constant;
}

void ir::IrBuilder::visit(ast::var_def_stmt_syntax &node)
{
    // 获取变量名和类型
    auto var_name = node.name;
    auto var_type = node.restype;
    
    // 在当前作用域创建变量
    auto var = std::make_shared<ir::ir_memobj>(var_name, cur_func->new_reg(var_type), 4); // 假设int是4字节
    scope.push_var(var_name, var);
    
    // 创建alloca指令
    cur_block->push_back(std::make_shared<ir::alloc>(var));
    
    // 处理初始化表达式（如果有）
    if (node.initializer) {
        node.initializer->accept(*this);
        auto init_value = pass_value;
        
        // 存储初始值到变量 - 参数顺序：(addr, value)
        cur_block->push_back(std::make_shared<ir::store>(var->get_addr(), init_value));
    }
}

void ir::IrBuilder::visit(ast::assign_stmt_syntax &node)
{
    // 获取左值（目标变量）
    auto var_name = node.target->name;
    auto var = scope.find_var(var_name);
    
    if (!var) {
        std::cerr << "Error: Variable " << var_name << " not found!" << std::endl;
        exit(1);
    }
    
    // 计算右侧表达式的值
    node.value->accept(*this);
    auto value = pass_value;
    
    // 存储值到目标变量 - 参数顺序：(addr, value)
    cur_block->push_back(std::make_shared<ir::store>(var->get_addr(), value));
    
    // 赋值结果是表达式的值
    this->pass_value = value;
}

void ir::IrBuilder::visit(ast::block_syntax &node)
{
    //由于我们的函数没有参数，所以，直接让block来处理scope的事情
    this->scope.enter();
    for(auto i :node.body)
    {
        i->accept(*this);
    }
    this->scope.exit();
}

void ir::IrBuilder::visit(ast::if_stmt_syntax &node)
{
    // 创建基本块：then块、else块（如果有）和合并块
    auto then_block = cur_func->new_block();
    auto merge_block = cur_func->new_block();
    std::shared_ptr<ir::ir_basicblock> else_block = nullptr;
    
    if (node.else_body) {
        else_block = cur_func->new_block();
    }
    
    // 处理条件表达式
    node.pred->accept(*this);
    auto cond_value = pass_value;
    
    // 创建条件跳转指令
    if (node.else_body) {
        // 如果有else分支，条件为真跳转到then_block，否则跳转到else_block
        cur_block->push_back(std::make_shared<ir::br>(cond_value, then_block, else_block));
    } else {
        // 如果没有else分支，条件为真跳转到then_block，否则跳转到merge_block
        cur_block->push_back(std::make_shared<ir::br>(cond_value, then_block, merge_block));
    }
    
    // 设置当前块为then块并处理then分支
    cur_block = then_block;
    if (node.then_body) {
        node.then_body->accept(*this);
    }
    
    // 在then分支末尾添加跳转到合并块的指令
    cur_block->push_back(std::make_shared<ir::jump>(merge_block));
    
    // 如果有else分支，处理else分支
    if (node.else_body) {
        // 设置当前块为else块
        cur_block = else_block;
        
        // 处理else分支
        node.else_body->accept(*this);
        
        // 在else分支末尾添加跳转到合并块的指令
        cur_block->push_back(std::make_shared<ir::jump>(merge_block));
    }
    
    // 设置当前块为合并块
    cur_block = merge_block;
}

void ir::IrBuilder::visit(ast::return_stmt_syntax &node)
{

    if(cur_func->rettype != vartype::VOID)//有返回值
    {
        node.exp->accept(*this);
        //放置好返回值和来源BB后跳转到return_bb
        return_value.emplace_back(pass_value,cur_block);
        cur_block->push_back(std::make_shared<ir::jump>(return_bb));
    }
    else//没有返回值
    {
        //直接跳转到return的BB
        auto jmp_inst = std::make_shared<ir::jump>(return_bb);
        cur_block->push_back(jmp_inst);
    }
    //对BB进行划分，这个BB用于防止return后面的部分（这部分永远不会被执行到）
    this->cur_block = this->cur_func->new_block();
}

void ir::IrBuilder::visit(ast::var_decl_stmt_syntax &node)
{
    for(auto i :node.var_def_list)
    {
        i->accept(*this);
    }
}
