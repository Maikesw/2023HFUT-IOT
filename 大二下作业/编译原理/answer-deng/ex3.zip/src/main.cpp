#include "parser/SyntaxTree.hpp"
#include "ir/irbuilder.hpp"
#include "ir/ir_printer.hpp"
#include <iostream>
#include <fstream>
#include <stdlib.h>

ast::SyntaxTree syntax_tree;

int main(){
    try {
        // 解析源代码生成AST
        ast::parse_file(std::cin);
        
        // 创建IR生成器
        std::shared_ptr<ir::IrBuilder> irbuilder = std::make_shared<ir::IrBuilder>();
        
        // 从AST生成IR
        syntax_tree.accept(*irbuilder);
        
        // 创建IR打印器并输出IR
        std::shared_ptr<ir::IrPrinter> irprinter = std::make_shared<ir::IrPrinter>();
        irbuilder->compunit->accept(*irprinter);
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    } catch (...) {
        std::cerr << "Unknown error occurred." << std::endl;
        return 1;
    }
    
    return 0;
}
