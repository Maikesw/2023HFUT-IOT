#include "SyntaxAnalyse.hpp"
#include "cstring"

extern ast::SyntaxTree syntax_tree;
//编译单位，包含一个或多个函数
void SyntaxAnalyseCompUnit(ast::compunit_syntax * &self, ast::compunit_syntax *compunit, ast::func_def_syntax *func_def)
{
    if(compunit){
        self = new ast::compunit_syntax;
        for(auto  i : compunit->global_defs){ //global_defs是ast::func_def_syntax型的list实例
            self->global_defs.emplace_back(std::shared_ptr<ast::func_def_syntax>(i));//共享指针被使用
        }
        self->global_defs.emplace_back(func_def);
    }else{
        self = new ast::compunit_syntax;
        self->global_defs.emplace_back(func_def);
    }
    syntax_tree.root = self;
}

//函数单位
void SyntaxAnalyseFuncDef(ast::func_def_syntax * &self, vartype var_type, char *Ident, ast::block_syntax *block)
{
    self = new ast::func_def_syntax;
    self->name = Ident;
    self->rettype = var_type;
    self->body =ptr<ast::block_syntax>(block);  
    
}

//定义时的函数返回值类型
void SynataxAnalyseFuncType(vartype &self, string type)
{if(type == "int") {self = vartype::INT;cout<<"ssssssssssssssssssssssssssss";}
    else if(type == "void") {self = vartype::VOID;cout<<"1111111111111111111111111111111";}
    
   
    
}

//大括号里的内容
void SynataxAnalyseBlock(ast::block_syntax *&self, ast::block_syntax *block_items)
{
    self = new ast::block_syntax;
    for(auto i : block_items->body){
        self->body.emplace_back(std::shared_ptr<ast::stmt_syntax>(i));
    }
}    

void SynataxAnalyseBlockItems(ast::block_syntax *&self, ast::block_syntax *block_items, ast::stmt_syntax *stmt)
{
   self = new ast::block_syntax;
   if(block_items && stmt){
   	for(auto i : block_items->body){
   		self->body.emplace_back(std::shared_ptr<ast::stmt_syntax>(i));
   	}
   	self->body.emplace_back(std::shared_ptr<ast::stmt_syntax>(stmt));
   }
   else if(!stmt && !block_items){
   	self = nullptr;
   }
   else {
   	self->body.emplace_back(std::shared_ptr<ast::stmt_syntax>(stmt));
   }
   
}

void SynataxAnalyseStmtReturn(ast::stmt_syntax *&self, ast::expr_syntax *exp)
{
    auto a = new ast::return_stmt_syntax;

  if(exp){
    a->exp = std::shared_ptr<ast::expr_syntax>(exp);
  }
  else{
    a->exp = std::shared_ptr<ast::expr_syntax>(nullptr);
  }



    self = a;


 

   
}
void SynataxAnalysePrimaryExpIntConst(ast::expr_syntax *&self, char *current_symbol)
{
       ast::literal_syntax* a = new ast::literal_syntax;
       a->intConst = atoi(current_symbol);
       vartype t = vartype::INT;
       a->restype = t;
       self = a;
}
//a-难度
void SynataxAnalyseStmtBlock(ast::stmt_syntax *&self, ast::block_syntax *block)
{
    auto a = new ast::block_syntax;
    for(auto i :block->body){
        a->body.emplace_back(std::shared_ptr<ast::stmt_syntax>(i));
    }
    self = a;
}

void SynataxAnalysePrimaryExpVar(ast::expr_syntax* &self, char* current_symbol)
{
    auto a = new ast::lval_syntax;
    a->name = current_symbol;
    a->restype = vartype::INT;
    self = a;
}

void SynataxAnalyseVarDecl(ast::stmt_syntax *&self, ast::var_def_stmt_syntax *var_def, ast::var_decl_stmt_syntax *var_def_group)
{
    auto a = new ast::var_decl_stmt_syntax;
    a->var_def_list.emplace_back(std::shared_ptr<ast::var_def_stmt_syntax>(var_def));
    if(var_def_group){
        for(auto i :var_def_group->var_def_list){
            a->var_def_list.emplace_back(std::shared_ptr<ast::var_def_stmt_syntax>(i));
        }

    }
    
    self = a;

}

void SynataxAnalyseVarDefGroup(ast::var_decl_stmt_syntax *&self, ast::var_def_stmt_syntax *var_def, ast::var_decl_stmt_syntax *var_def_group)
{    
    self = new ast::var_decl_stmt_syntax;
    if(var_def ){
        self->var_def_list.emplace_back(var_def);
        if(var_def_group){
                for(auto i :var_def_group->var_def_list){
            self->var_def_list.emplace_back(std::shared_ptr<ast::var_def_stmt_syntax>(i));
            }

        }
        
        
    }
    else{
        self->var_def_list.emplace_back(std::shared_ptr<ast::var_def_stmt_syntax>(nullptr));
    }
}

void SynataxAnalyseVarDef(ast::var_def_stmt_syntax *&self, char *ident, ast::expr_syntax *init)
{
    self = new ast::var_def_stmt_syntax;
    if(init){
        self->restype = vartype::INT;
        self->name = ident;
        self->initializer = std::shared_ptr<ast::expr_syntax>(init);
    }
    else{
        self->restype = vartype::INT;
        self->name = ident;
        self->initializer = nullptr;
    }

}

void SynataxAnalyseAddExp(ast::expr_syntax *&self, ast::expr_syntax *exp1, char *op, ast::expr_syntax *exp2)
{
    auto a = new ast::binop_expr_syntax;
    string str = op;
    a->lhs = std::shared_ptr<ast::expr_syntax>(exp1);
    a->rhs = std::shared_ptr<ast::expr_syntax>(exp2);
    if(str == "+") a->op = binop::plus;
    else if(str == "-") a->op = binop::minus; //???
    a->restype = vartype::INT;


    self = a;

}
//a难度
void SynataxAnalyseMulExp(ast::expr_syntax *&self, ast::expr_syntax *exp1, char *op, ast::expr_syntax *exp2)
{
    auto a = new ast::binop_expr_syntax;
    a->lhs = std::shared_ptr<ast::expr_syntax>(exp1);
    a->rhs = std::shared_ptr<ast::expr_syntax>(exp2);
    string str = op;
    if(str == "*") a->op = binop::multiply;
    else if(str == "/") a->op = binop::divide;    
    a->restype = vartype::INT;


    self = a;

}

void SynataxAnalyseStmtAssign(ast::stmt_syntax *&self, ast::lval_syntax *target, ast::expr_syntax *value)
{
    auto a = new ast::assign_stmt_syntax;
    a->value =  std::shared_ptr<ast::expr_syntax>(value);
    a->target = std::shared_ptr<ast::lval_syntax>(target);
    self = a;
   

}

void SynataxAnalyseLval(ast::lval_syntax *&self, char *ident)
{
    self = new ast::lval_syntax;
    self->name = ident;
    self->restype = vartype::INT;
}
//a+难度
void SynataxAnalyseStmtIf(ast::stmt_syntax *&self, ast::expr_syntax *cond, ast::stmt_syntax *then_body, ast::stmt_syntax *else_body)
{
    auto a = new ast::if_stmt_syntax;
    if(else_body){
        a->pred = std::shared_ptr<ast::expr_syntax>(cond);
        a->then_body = std::shared_ptr<ast::stmt_syntax>(then_body);
        a->else_body = std::shared_ptr<ast::stmt_syntax>(else_body);
    }
    else{
        a->pred = std::shared_ptr<ast::expr_syntax>(cond);
        a->then_body = std::shared_ptr<ast::stmt_syntax>(then_body);
        a->else_body = std::shared_ptr<ast::stmt_syntax>(nullptr);       
    }

    self = a;
}

void SynataxAnalyseLOrExp(ast::expr_syntax *&self, ast::expr_syntax *cond1, ast::expr_syntax *cond2)
{
    auto a = new ast::logic_cond_syntax;
    a->op = relop::op_and;
    a->lhs = std::shared_ptr<ast::expr_syntax>(cond1);
    a->rhs = std::shared_ptr<ast::expr_syntax>(cond2);


    self = a;
}

void SynataxAnalyseLAndExp(ast::expr_syntax *&self, ast::expr_syntax *cond1, ast::expr_syntax *cond2)
{
    auto a = new ast::logic_cond_syntax;
    a->op = relop::op_or;
    a->lhs = std::shared_ptr<ast::expr_syntax>(cond1);
    a->rhs = std::shared_ptr<ast::expr_syntax>(cond2);


    self = a;
}

void SynataxAnalyseEqExp(ast::expr_syntax *&self, ast::expr_syntax *cond1, char *op, ast::expr_syntax *cond2)
{
    auto a = new ast::rel_cond_syntax;
    string str = op;
    a->lhs = std::shared_ptr<ast::expr_syntax>(cond1);
    a->rhs = std::shared_ptr<ast::expr_syntax>(cond2);
    if(str == "==") a->op = relop::equal;
    else if(str == "!=") a->op = relop::non_equal;


    self = a;
}


void SynataxAnalyseRelExp(ast::expr_syntax *&self, ast::expr_syntax *cond1, char *op, ast::expr_syntax *exp)
{
    auto a = new ast::rel_cond_syntax;
    string str = op;
    a->lhs = std::shared_ptr<ast::expr_syntax>(cond1);
    a->rhs = std::shared_ptr<ast::expr_syntax>(exp);
    if(str == "<") a->op = relop::less;
    else if(str == ">") a->op = relop::greater;
    else if(str == "<=") a->op = relop::less_equal;
    else if(str == ">=") a->op = relop::greater_equal;

    



    self = a;

}

void SynataxAnalyseUnaryExp(ast::expr_syntax *&self, char *op, ast::expr_syntax *exp)
{
    auto a = new ast::unaryop_expr_syntax;
    string str = op;
    if(str == "+") a->op = unaryop::plus;
    else if(str == "-") a->op = unaryop::minus;
    else if(str == "!") a->op = unaryop::op_not;
    
    a->rhs = std::shared_ptr<ast::expr_syntax>(exp);
    

    self = a;
}
