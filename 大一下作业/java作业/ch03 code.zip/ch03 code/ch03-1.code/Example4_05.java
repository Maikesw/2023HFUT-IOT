public class Example4_05 
{ 
    public static void main(String args[]) 
    {
    	Player huangA = new Player();
    	huangA.setInfo("Ronaldo", 1.86);
       
       Player pMostFamous = new Player();
       pMostFamous = huangA;
          
       pMostFamous.setInfo("Messi", 1.89);
       System.out.println(huangA.name);
       System.out.println(huangA.height);
    }    
}
class Player
{
	final int PI;
	String name; //����
	double height; //����
	String teamName;  //�����ĸ����
	String gameNames[];  //�μӹ��ı�������
	int scores[];    //ÿ�α����еĵ÷�
	
	Player()
	{
	}
	void setInfo(String name, double height)
	{ 
		this.name = name;
		this.height = height;
	}
}
