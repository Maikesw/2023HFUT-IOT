interface Demo
{
	//Ĭ�ϵ�
	//public static final int NUM = 4;
	//public abstract void show1();
	//public abstract void show2();
	
	//���Լ�д��
	int NUM = 4;
	void show1();
	void show2();
}

class InterfaceDemo implements Demo
{
	public void show1()
	{  	}
	public void show2()
	{ 	}
}

class TestExample
{
	public static void main(String[] args)
	{
		InterfaceDemo d = new InterfaceDemo();
		//d.NUM = 3;  //���ԣ�NUMΪfinal���͵�
		System.out.println(d.NUM);
		System.out.println(Demo.NUM);
		System.out.println(InterfaceDemo.NUM);
	}
}